package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.myapplication.model.classes.base.Classe as ModelClasse
import com.example.myapplication.model.classes.implementacoes.Clerigo
import com.example.myapplication.model.classes.implementacoes.Guerreiro
import com.example.myapplication.model.classes.implementacoes.Ladrao
import com.example.myapplication.model.classes.implementacoes.Mago
import com.example.myapplication.ui.theme.classe.displayName
import com.example.myapplication.ui.theme.classe.imageRes
import com.example.myapplication.ui.theme.MyApplicationTheme

const val EXTRA_CLASSE = "CLASSE"

class MainActivity3 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val nome = intent.getStringExtra(EXTRA_NOME) ?: "Herói sem nome"
        val raca = intent.getStringExtra(EXTRA_RACA) // opcional

        setContent {
            MyApplicationTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    EscolherClasse(
                        nomePersonagem = nome,
                        onSelecionar = { classe ->
                            // Exemplo: seguir para a próxima etapa ou finalizar criação
                            val prox = Intent(this, MainActivity4::class.java).apply {
                                putExtra(EXTRA_NOME, nome)
                                putExtra(EXTRA_RACA, raca)
                                putExtra(EXTRA_CLASSE, classe::class.java.simpleName)
                            }
                            startActivity(prox)
                            // finish() // se quiser fechar esta tela
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun EscolherClasse(
    nomePersonagem: String,
    onSelecionar: (ModelClasse) -> Unit
) {
    // catálogo de classes base — ajuste se seus construtores tiverem parâmetros
    val classes: List<ModelClasse> = remember {
        listOf(Guerreiro(), Ladrao(), Mago(), Clerigo())
    }

    var index by remember { mutableStateOf(0) }
    val atual = classes[index]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Escolha a classe", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text("Personagem: $nomePersonagem", style = MaterialTheme.typography.bodyMedium)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 240.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = {
                index = if (index == 0) classes.lastIndex else index - 1
            }) { Icon(Icons.Filled.ArrowBack, contentDescription = "Anterior") }

            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(atual.imageRes()),
                    contentDescription = atual.displayName(),
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .aspectRatio(1f)
                )
                Spacer(Modifier.height(8.dp))
                Text(atual.displayName(), style = MaterialTheme.typography.titleMedium)
            }

            IconButton(onClick = {
                index = if (index == classes.lastIndex) 0 else index + 1
            }) { Icon(Icons.Filled.ArrowForward, contentDescription = "Próxima") }
        }

        Button(onClick = { onSelecionar(atual) }) {
            Text("Selecionar classe")
        }
    }
}
