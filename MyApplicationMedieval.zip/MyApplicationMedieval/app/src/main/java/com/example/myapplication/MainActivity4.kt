package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.myapplication.ui.theme.subclasse.subclasseDisplayName
import com.example.myapplication.ui.theme.subclasse.subclasseImageRes
import com.example.myapplication.ui.theme.MyApplicationTheme

const val EXTRA_SUB    = "SUBCLASSE"

class MainActivity4 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val nome   = intent.getStringExtra(EXTRA_NOME) ?: "Herói sem nome"
        val raca   = intent.getStringExtra(EXTRA_RACA)
        val classe = intent.getStringExtra(EXTRA_CLASSE)

        setContent {
            MyApplicationTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    TelaSubclasse(
                        nomePersonagem = nome,
                        onPular = {
                            // segue sem subclasse por enquanto → vai para a MainActivity5
                            val prox = Intent(this, MainActivity5::class.java).apply {
                                putExtra(EXTRA_NOME, nome)
                                putExtra(EXTRA_RACA, raca)
                                putExtra(EXTRA_CLASSE, classe)
                                // sem EXTRA_SUB
                            }
                            startActivity(prox)
                        },
                        onSelecionar = { subEscolhida ->
                            // escolheu subclasse → também vai para a MainActivity5
                            val prox = Intent(this, MainActivity5::class.java).apply {
                                putExtra(EXTRA_NOME, nome)
                                putExtra(EXTRA_RACA, raca)
                                putExtra(EXTRA_CLASSE, classe)
                                putExtra(EXTRA_SUB, subEscolhida::class.java.simpleName)
                            }
                            startActivity(prox)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun TelaSubclasse(
    nomePersonagem: String,
    onPular: () -> Unit,
    onSelecionar: (Any) -> Unit
) {
    // Catálogo de subclasses do seu Model (ajuste se tiver parâmetros)
    val lista = remember {
        listOf(
            com.example.myapplication.model.classes.subclasses.Academico(),
            com.example.myapplication.model.classes.subclasses.Barbaro(),
            com.example.myapplication.model.classes.subclasses.Bardo(),
            com.example.myapplication.model.classes.subclasses.Druida(),
            com.example.myapplication.model.classes.subclasses.Ilusionista(),
            com.example.myapplication.model.classes.subclasses.Necromante(),
            com.example.myapplication.model.classes.subclasses.Paladino(),
            com.example.myapplication.model.classes.subclasses.Ranger(),
        )
    }

    var escolherAgora by remember { mutableStateOf<Boolean?>(null) }
    var index by remember { mutableStateOf(0) }
    val atual = lista[index]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Deseja escolher uma subclasse agora?",
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center
        )
        Text("Personagem: $nomePersonagem", style = MaterialTheme.typography.bodyMedium)

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Button(onClick = { escolherAgora = true }) { Text("Sim, escolher agora") }
            OutlinedButton(onClick = { escolherAgora = false }) { Text("Não, decidir depois") }
        }

        when (escolherAgora) {
            null -> Unit
            false -> {
                Spacer(Modifier.height(8.dp))
                Text("Você pode definir a subclasse depois.", style = MaterialTheme.typography.bodyMedium)
                Button(onClick = onPular) { Text("Continuar") }
            }
            true -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 240.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = {
                        index = if (index == 0) lista.lastIndex else index - 1
                    }) { Icon(Icons.Filled.ArrowBack, contentDescription = "Anterior") }

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(atual.subclasseImageRes()),
                            contentDescription = atual.subclasseDisplayName(),
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .aspectRatio(1f)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(atual.subclasseDisplayName(), style = MaterialTheme.typography.titleMedium)
                    }

                    IconButton(onClick = {
                        index = if (index == lista.lastIndex) 0 else index + 1
                    }) { Icon(Icons.Filled.ArrowForward, contentDescription = "Próxima") }
                }

                Button(onClick = { onSelecionar(atual) }) {
                    Text("Selecionar subclasse")
                }
            }
        }
    }
}
