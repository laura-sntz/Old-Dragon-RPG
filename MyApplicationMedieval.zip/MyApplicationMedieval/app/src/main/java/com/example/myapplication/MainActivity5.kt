package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.myapplication.model.atributos.NomeAtributo
import com.example.myapplication.model.distribuicao.EstiloRolagem
import com.example.myapplication.model.distribuicao.estiloParaMetodo
import com.example.myapplication.ui.theme.MyApplicationTheme

const val EXTRA_ATTRS  = "ATRIBUTOS_ARRAY"  // IntArray com os 6 valores na ordem do enum

class MainActivity5 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val nome   = intent.getStringExtra(EXTRA_NOME) ?: "Herói sem nome"
        val raca   = intent.getStringExtra(EXTRA_RACA)
        val classe = intent.getStringExtra(EXTRA_CLASSE) ?: ""
        val sub    = intent.getStringExtra(EXTRA_SUB)    // pode ser nulo

        setContent {
            MyApplicationTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    DistribuicaoScreen(
                        nomePersonagem = nome,
                        classeSimpleName = classe,
                        onConcluir = { mapa ->
                            // empacota os atributos na ordem do enum
                            val ordered = NomeAtributo.values().map { mapa[it] ?: 10 }.toIntArray()
                            val prox = Intent(this, MainActivity6::class.java).apply {
                                putExtra(EXTRA_NOME, nome)
                                putExtra(EXTRA_RACA, raca)
                                putExtra(EXTRA_CLASSE, classe)
                                if (sub != null) putExtra(EXTRA_SUB, sub)
                                putExtra(EXTRA_ATTRS, ordered)
                            }
                            startActivity(prox)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DistribuicaoScreen(
    nomePersonagem: String,
    classeSimpleName: String,
    onConcluir: (Map<NomeAtributo, Int>) -> Unit
) {
    var estilo by remember { mutableStateOf(EstiloRolagem.CLASSICO) }
    var rolagens by remember { mutableStateOf(emptyList<Int>()) }

    val atributos: List<NomeAtributo> = remember { NomeAtributo.values().toList() }

    var atribuicoes by remember {
        mutableStateOf<Map<NomeAtributo, Int?>>(atributos.associateWith { null })
    }

    fun limparDistribuicao() {
        atribuicoes = atributos.associateWith { null }
    }

    val restantes: List<Int> = remember(rolagens, atribuicoes) {
        val usados = atribuicoes.values.filterNotNull()
        val copia = rolagens.toMutableList()
        usados.forEach { v -> copia.remove(v) }
        copia
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Distribuição de Atributos", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text("Personagem: $nomePersonagem", style = MaterialTheme.typography.bodyMedium)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetodoChip("Clássico", estilo == EstiloRolagem.CLASSICO) { estilo = EstiloRolagem.CLASSICO }
            MetodoChip("Aventureiro", estilo == EstiloRolagem.AVENTUREIRO) { estilo = EstiloRolagem.AVENTUREIRO }
            MetodoChip("Heróico", estilo == EstiloRolagem.HEROICO) { estilo = EstiloRolagem.HEROICO }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                rolagens = estiloParaMetodo(estilo).gerarAtributos()
                limparDistribuicao()
            }) { Text("Gerar rolagens") }

            OutlinedButton(
                onClick = { autoDistribuir(classeSimpleName, rolagens) { atribuicoes = it } },
                enabled = rolagens.size == 6
            ) { Text("Preencher automaticamente") }

            TextButton(onClick = { limparDistribuicao() }) { Text("Limpar") }
        }

        if (rolagens.isNotEmpty()) {
            Text("Rolagens: ${rolagens.joinToString(", ")}")
            Text("Restantes: ${restantes.joinToString(", ").ifEmpty { "—" }}")
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            atributos.forEach { atributo ->
                val atual = atribuicoes[atributo]
                val opcoes = restantes + listOfNotNull(atribuicoes[atributo]) // mantém se já tiver
                AtributoPickerRow(
                    atributo = atributo,
                    valorAtual = atual,
                    opcoes = opcoes
                ) { novoValor ->
                    atribuicoes = atribuicoes.toMutableMap().apply { this[atributo] = novoValor }
                }
            }
        }

        val tudoPreenchido = atribuicoes.values.all { it != null }
        Button(
            onClick = { onConcluir(atribuicoes.mapValues { it.value!! }) },
            enabled = tudoPreenchido
        ) { Text("Concluir distribuição") }
    }
}

@Composable
private fun MetodoChip(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(text) })
}

@Composable
private fun AtributoPickerRow(
    atributo: NomeAtributo,
    valorAtual: Int?,
    opcoes: List<Int>,
    onEscolher: (Int?) -> Unit
) {
    var menuAberto by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("${atributo.name} (${atributo.sigla})", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(valorAtual?.toString() ?: "—")
            OutlinedButton(onClick = { menuAberto = true }, enabled = opcoes.isNotEmpty()) { Text("Escolher") }
            DropdownMenu(expanded = menuAberto, onDismissRequest = { menuAberto = false }) {
                DropdownMenuItem(text = { Text("— (limpar)") }, onClick = { menuAberto = false; onEscolher(null) })
                opcoes.forEach { v ->
                    DropdownMenuItem(text = { Text(v.toString()) }, onClick = { menuAberto = false; onEscolher(v) })
                }
            }
        }
    }
}

private fun autoDistribuir(
    classeSimpleName: String,
    rolagens: List<Int>,
    onAtribuir: (Map<NomeAtributo, Int?>) -> Unit
) {
    if (rolagens.size != 6) return
    val prioridade: List<NomeAtributo> = when (classeSimpleName) {
        "Guerreiro" -> listOf(NomeAtributo.FORCA, NomeAtributo.CONSTITUICAO, NomeAtributo.DESTREZA, NomeAtributo.SABEDORIA, NomeAtributo.CARISMA, NomeAtributo.INTELIGENCIA)
        "Mago"      -> listOf(NomeAtributo.INTELIGENCIA, NomeAtributo.SABEDORIA, NomeAtributo.DESTREZA, NomeAtributo.CONSTITUICAO, NomeAtributo.CARISMA, NomeAtributo.FORCA)
        "Clerigo"   -> listOf(NomeAtributo.SABEDORIA, NomeAtributo.CONSTITUICAO, NomeAtributo.FORCA, NomeAtributo.CARISMA, NomeAtributo.DESTREZA, NomeAtributo.INTELIGENCIA)
        "Ladrao"    -> listOf(NomeAtributo.DESTREZA, NomeAtributo.INTELIGENCIA, NomeAtributo.CARISMA, NomeAtributo.CONSTITUICAO, NomeAtributo.SABEDORIA, NomeAtributo.FORCA)
        else        -> listOf(NomeAtributo.FORCA, NomeAtributo.CONSTITUICAO, NomeAtributo.DESTREZA, NomeAtributo.INTELIGENCIA, NomeAtributo.SABEDORIA, NomeAtributo.CARISMA)
    }
    val ordenados = rolagens.sortedDescending()
    val out = mutableMapOf<NomeAtributo, Int?>()
    prioridade.forEachIndexed { i, atr -> out[atr] = ordenados.getOrNull(i) }
    onAtribuir(out)
}
