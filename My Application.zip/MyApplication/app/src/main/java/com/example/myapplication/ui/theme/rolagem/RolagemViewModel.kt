package com.example.myapplication.ui.theme.rolagem

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import com.example.myapplication.model.distribuicao.*

// Estado que a tela vai observar
data class RolagemState(
    val estilo: EstiloRolagem = EstiloRolagem.CLASSICO,
    val valores: List<Int> = emptyList()  // 6 valores gerados
)

// ViewModel que liga a UI com o Model
class RolagemViewModel : ViewModel() {
    private val _state = MutableStateFlow(RolagemState())
    val state: StateFlow<RolagemState> = _state

    // Seleciona o estilo (clássico, aventureiro, heróico)
    fun selecionar(estilo: EstiloRolagem) {
        _state.value = _state.value.copy(estilo = estilo)
    }

    // Gera os atributos usando o estilo atual
    fun gerar() {
        val metodo: MetodoDistribuicao = estiloParaMetodo(_state.value.estilo)
        val novos = metodo.gerarAtributos()
        _state.value = _state.value.copy(valores = novos)
    }
}