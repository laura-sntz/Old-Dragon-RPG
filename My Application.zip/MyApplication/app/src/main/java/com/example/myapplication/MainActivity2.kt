package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.myapplication.model.personagens.racas.Raca as ModelRaca
import com.example.myapplication.model.personagens.racas.Humano
import com.example.myapplication.model.personagens.racas.Elfo
import com.example.myapplication.model.personagens.racas.Anao
import com.example.myapplication.model.personagens.racas.Halfling
import com.example.myapplication.ui.theme.raca.displayName
import com.example.myapplication.ui.theme.raca.imageRes
import com.example.myapplication.ui.theme.MyApplicationTheme


const val EXTRA_RACA = "RACA"
class MainActivity2 : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // vem da primeira tela
        val nome = intent.getStringExtra(EXTRA_NOME) ?: "Herói sem nome"

        setContent {
            MyApplicationTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    EscolherRacaScreen(
                        nomePersonagem = nome,
                        onSelecionar = { racaEscolhida ->
                            // Exemplo: ir para a próxima etapa (EstiloActivity)
                            val prox = Intent(this, MainActivity3::class.java).apply {
                                putExtra(EXTRA_NOME, nome)
                                putExtra(EXTRA_RACA, racaEscolhida::class.java.simpleName)
                                // se quiser, salve algo mais robusto (id) em vez do nome da classe
                            }
                            startActivity(prox)
                            // ou termine esta tela:
                            // finish()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun EscolherRacaScreen(
    nomePersonagem: String,
    onSelecionar: (ModelRaca) -> Unit
) {
    // catálogo de raças (se seus construtores tiverem parâmetros, ajuste aqui)
    val racas: List<ModelRaca> = remember {
        listOf(Humano(), Elfo(), Anao(), Halfling())
    }

    var index by remember { mutableStateOf(0) }
    val atual = racas[index]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Escolha a raça", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text("Personagem: $nomePersonagem", style = MaterialTheme.typography.bodyMedium)

        // Imagem central + setas
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 240.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = {
                index = if (index == 0) racas.lastIndex else index - 1
            }) { Icon(Icons.Filled.ArrowBack, contentDescription = "Anterior") }

            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(atual.imageRes()),
                    contentDescription = atual.displayName(),
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .aspectRatio(1f) // quadrado; ajuste como quiser
                )
                Spacer(Modifier.height(8.dp))
                Text(atual.displayName(), style = MaterialTheme.typography.titleMedium)
            }

            IconButton(onClick = {
                index = if (index == racas.lastIndex) 0 else index + 1
            }) { Icon(Icons.Filled.ArrowForward, contentDescription = "Próxima") }
        }

        Button(onClick = { onSelecionar(atual) }) {
            Text("Selecionar raça")
        }
    }
}
