package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myapplication.model.distribuicao.EstiloRolagem
import com.example.myapplication.model.distribuicao.estiloParaMetodo
import com.example.myapplication.ui.theme.MyApplicationTheme

class MainActivity2 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    TelaEstilo()
                }
            }
        }
    }
}


@Composable
fun TelaEstilo() {
    var estilo by remember { mutableStateOf(EstiloRolagem.CLASSICO) }
    var valores by remember { mutableStateOf<List<Int>>(emptyList()) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Estilo de rolagem", style = MaterialTheme.typography.titleLarge)

        // opções
        EstiloOption("Clássico (3d6 na ordem)", estilo == EstiloRolagem.CLASSICO) {
            estilo = EstiloRolagem.CLASSICO
        }
        EstiloOption("Aventureiro (3d6, distribua à vontade)", estilo == EstiloRolagem.AVENTUREIRO) {
            estilo = EstiloRolagem.AVENTUREIRO
        }
        EstiloOption("Heróico (4d6 descarta o menor)", estilo == EstiloRolagem.HEROICO) {
            estilo = EstiloRolagem.HEROICO
        }

        Button(onClick = {
            // chama teu back (Model)
            val metodo = estiloParaMetodo(estilo)
            valores = metodo.gerarAtributos()
        }) {
            Text("Rolar atributos")
        }

        if (valores.isNotEmpty()) {
            Text("Resultados:", style = MaterialTheme.typography.titleMedium)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(valores.size) { i ->
                    ElevatedCard { Text("Valor ${i + 1}: ${valores[i]}", Modifier.padding(12.dp)) }
                }
            }
        }
    }
}

@Composable
private fun EstiloOption(titulo: String, selecionado: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        RadioButton(selected = selecionado, onClick = onClick)
        Text(titulo, modifier = Modifier.weight(1f))
    }
}
